//
//  Play.h
//  PlayArea
//
//  Created by zayan on 2/13/16.
//  Copyright (c) 2016 Eftiquar. All rights reserved.
//

#ifndef __PlayArea__Play__
#define __PlayArea__Play__

#include "algorist.h"

INPUTLIST DialThis(wstring input,map<wchar_t,wstring> & neighbours);
STRINGS CombineThem(const wstring& in,size_t n );
STRINGS PermutateF(wstring in);
STRINGS PowerSet(wstring in);
vector<size_t> GetPossiblePositions(size_t npos, int nDays);
void BackTrack(vector<size_t> solutions, size_t level, size_t target, const STRINGS& input);

vector<int> LIS( const vector<int> & sequence);
vector<int> MaxZigZAg(const vector<int> & sequence);
vector<wstring> Justify(const wstring & textInput, const size_t length);
size_t MaxRod(const size_t* begin,const size_t* end);
size_t KnapTheSack(vector<std::pair<size_t,size_t> >values, size_t capacity);
std::vector<wstring> JustifyText(const wstring& text, int lineWidth);
size_t LCS (const wchar_t* lhsbegin,const wchar_t* lhsend,const wchar_t* rhsbegin,const wchar_t* rhsend );
size_t GetDenoes(const size_t targetAmount, const std::vector<size_t>& denominations);
std::vector<size_t> KnapsackFull(std::vector<std::pair<size_t,size_t>> items,size_t capacity );
std::vector<std::pair<size_t,size_t>> MergeIngervals(std::vector<std::pair<size_t,size_t>> intervals);

#endif /* defined(__PlayArea__Play__) */
