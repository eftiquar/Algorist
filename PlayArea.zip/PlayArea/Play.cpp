//
//  Play.cpp
//  PlayArea
//
//  Created by zayan on 2/13/16.
//  Copyright (c) 2016 Eftiquar. All rights reserved.
//

#include "Play.h"
#include <iostream>
#include <string>
#include <algorithm>
#include <iterator>
#include <numeric>
//find min path in a grid
// input source pair - x , y , dest pair x, y
//return list of pair



PATH FindMinHelper(POINT start, POINT destination)
{
    PATH result ;
    if(start == destination)
        return {start};
    
    if (destination.second == start.second && destination.first == 1)
    {
        return {start};
    }
    if(destination.first == start.first && destination.second ==1)
    {
        return {start};
    }
    auto minXPrev = FindMinHelper(start,{destination.first > 1 ? destination.first -1 :0, destination.first ? destination.second : destination.second -1});
    auto minYPrev = FindMinHelper(start,{destination.second ? destination.first : destination.first-1,destination.second > 1 ?destination.second-1 :0});
    

    
    if(minXPrev.size() < minYPrev.size())
    {
        if(destination.first == 0 && destination.second ==0)
        {
            minXPrev.push_back(destination);
        }
        else
        {
        minXPrev.push_back({destination.first > 1 ? destination.first -1 :0, destination.first ? destination.second : destination.second -1});
        }
        return minXPrev;
    }
    else
    {
        if(destination.first == 0 && destination.second ==0)
        {
            minXPrev.push_back(destination);
        }
        else
        {
        minYPrev.push_back({destination.second ? destination.first : destination.first-1,destination.second > 1 ?destination.second-1 :0});
        }
        return minYPrev;
    }
    

}


void FindMin(POINT start, POINT destination)
{
    auto path =    FindMinHelper(start,destination);
    path.push_back(destination);
    
    for(auto segment :path)
    {
        std::cout << segment.first << segment.second << L"\n";
    }
}

INPUTLIST DialThis(wstring::iterator cursor,wstring::iterator end,  map<wchar_t,wstring> & neighbours)
{
    if(cursor == end)
    {
        return {L""};
    }
    if(cursor + 1 == end)
    {
        INPUTLIST thisResult;
        //thisResult.push_back({wstring(1,*cursor)});
        std::transform(neighbours[*cursor].begin(),neighbours[*cursor].end(),std::back_inserter(thisResult), [](wchar_t ch){return wstring(1,ch);});
        return thisResult;
        
    }
    INPUTLIST result = DialThis(cursor+1, end, neighbours);
    INPUTLIST thisResult;
    
    for(auto subResultCursor:result)
    {
        //thisResult.push_back(*cursor + subResultCursor);
        std::transform(neighbours[*cursor].begin(),neighbours[*cursor].end(),std::back_inserter(thisResult),
                       [&subResultCursor](wchar_t ch)
        {
            
            return ch + subResultCursor;
        });
    }
    return thisResult;
}
INPUTLIST DialLoop(wstring::iterator cursor,wstring::iterator end,  map<wchar_t,wstring> & neighbours);
INPUTLIST DialThis(wstring input,map<wchar_t,wstring> & neighbours)
{
 //return DialThis(input.begin(),input.end(),neighbours);
    return DialLoop(input.begin(), input.end(), neighbours);

}

/*
 a    d     g
 b    e     h
 c    f     i
 
 000
 001
 002
 
 010
 011
 012
 
 020
 021
 022
 
 100
 101
 102
 
 110
 111
 112
 
 120
 121
 122
 
 200
 201
 202
 
 210
 211
 212
 
 220
 221
 222
 
 
 b b
   c
 ab
 ac
 
 bc
 
 a b c
 abc
 bc
 
 a b
 b c
 c
 
 b c
 c
 
 ab
 ac
 bc
 
 helto
 h  e l
 e  l t
 l
 t
 0 1 2 
 0 1 3
 0 1 4
 
 0 2 3
 0 2 4
 
 0 3 4
 
 1 2  3
   3
   4
 
 1 3 4
 
 
*/


INPUTLIST DialLoop(wstring::iterator cursor,wstring::iterator end,  map<wchar_t,wstring> & neighbours)
{
    INPUTLIST result;
    wstring base(cursor,end);

    auto distanceEnd = neighbours[*cursor].length();
    
    vector< wstring::iterator::difference_type> cursors;
    std::transform(cursor, end, std::back_inserter(cursors),[](wchar_t ch)
                   {
                       return 0;
                   }
                   );
    for(;;)
    {
        wstring thisResult;
        auto distance = 0;
        std::transform(cursor, end, std::back_inserter(thisResult),
                       [&cursors, &distance,&neighbours](wchar_t ch)
                       {
                           
                           return neighbours[ch][cursors[distance++]];
                       });
        
        result.push_back(thisResult);
        
        bool carryFlag = 0;
        for(auto rcursor = cursors.rbegin();rcursor!=cursors.rend();rcursor++)
        {
                if(*rcursor +1 == distanceEnd)
                {
                    *rcursor = 0;
                    carryFlag = true;
                }
                else
                {
                    //carry absorbed, carry on
                    *rcursor +=1;
                    carryFlag = false;
                }
              if(!carryFlag)
                  break;
        }
        //overflow occured, quit
        if(carryFlag)
            break;
    }
    return result;
}


/*
 7 / -3 = -2*-3 + 1
 -2/-3 = 0 , -2 
 
 -2 = -3*0 - 2
    = -3*(0 + 1 - 1) - 2
    =
 a/b = q, 
 a = bq - r
 a = bq +b -b -r
 bq + b -(b+r)
 q(b+1) - (b+r)
 
 r >=0 && r < b 
 if(r <0) 
 a = b(q +1 -1) + r
 a = b(q+1) -b + r
 a = b(q-1) +b +r 
 
 
 */

bool PermutateF(wstring::iterator first,wstring::iterator end)
{
    if(first == end)
        return false;
    
    auto lastCursor = end;
    
    if(first == --lastCursor)
        return false;

    
    for(;;)
    {

        auto thisLast = lastCursor;
        if(*--lastCursor < *thisLast)
        {
            auto dipPoint = lastCursor;
            auto endCursor = end;
            //while dip point is not less than endcursor
            while(!(*dipPoint < *--endCursor))
                ;
            std::swap(*dipPoint, *endCursor);
            std::reverse(thisLast,end);
            return true;
        }
        else if(lastCursor == first)
        {
            return false;
        }
    }

}
STRINGS PermutateF(wstring in)
{
    STRINGS res;
    std::sort(in.begin(),in.end());
    
    auto first = in.begin();
    auto last = in.end();

    //base case
    res.push_back(wstring(first,last));
    
   while(PermutateF(first,last))
   {
       res.push_back(wstring(first,last));
   }
    
    return res;
}
std::map<size_t,size_t> GenerateLogVector()
{
    vector<size_t>  logs(32);
    size_t n = 0;
    std::map<size_t,size_t> logMap;
    std::generate(logs.begin(),logs.end(), [&n,&logMap]()
                  {
                      size_t powThis = 1 << n;
                      logMap[powThis] = n;
                      return n++;
                  });
    return logMap;
}

STRINGS PowerSet(wstring in)
{
    STRINGS powerset;
    std::map<size_t,size_t>  logsMap = GenerateLogVector();
    
    size_t end = 1 << in.length();
    size_t strlen = in.length();
    for(size_t begin = 0; begin !=end;++begin)
    {
       wstring thisSubset;
       auto masks = begin;
       while(masks)
       {
           size_t mask = masks & (~ (masks -1));
           thisSubset += in[strlen - 1 - logsMap[mask]];
           masks &= (masks-1);
       }
        std::reverse(thisSubset.begin(),thisSubset.end());
        powerset.emplace_back(thisSubset);
    }
    return powerset;
}
auto constexpr hashMod = 997;
auto constexpr base = 26;
bool RabinCarp(wstring target, wstring in)
{
    size_t targetHash = 0;
    size_t inHash = 0;
    size_t baseMaxPower = 0;
    std::transform(target.begin(),target.end(),in.begin(),in.begin(), [&targetHash,&inHash,&baseMaxPower] (wchar_t t, wchar_t s)
              {
                  baseMaxPower = baseMaxPower ? (baseMaxPower* base) % hashMod : 1;
                  targetHash = (targetHash * baseMaxPower + t - L'0')/hashMod;
                  inHash = (inHash * baseMaxPower + s - L'0')/hashMod;
                  
                  return s;
              }
              );
    for(auto cursor = target.length(); in.length() - cursor < target.length();cursor ++)
    {
        if(targetHash == inHash && !in.compare(cursor - target.length(),cursor,target))
            return cursor;
            
        
    }
      return false;
}

vector<size_t> GetPossiblePositions(size_t npos, int nDays)
{
    vector<size_t> positions;
    
    auto start = 1 << npos;
    positions.push_back(start);
    
    auto next = 0;
    
    for(;;)
    {
        auto rightMost = start & ~ (start -1);
        if(rightMost >1 /*&& rightMost < (1 << 31)*/)
        {
            next |= rightMost >> 1;
            next |= rightMost << 1;
        }
        if(rightMost ==1 )
        {
            next |= rightMost <<1;
        }
        else if(rightMost == (1 <<31))
        {
            next |= rightMost >> 1;
        }
        start &= (start -1);
        
        if(!start)
        {
            positions.push_back(next);
            if(positions.size() == nDays)
                break;
            start = next;
            next = 0;
        }
    }
    
    return positions;
}