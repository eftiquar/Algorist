//
//  Play.h
//  PlayArea
//
//  Created by zayan on 2/13/16.
//  Copyright (c) 2016 Eftiquar. All rights reserved.
//

#ifndef __PlayArea__Play__
#define __PlayArea__Play__

#include "algorist.h"

INPUTLIST DialThis(wstring input,map<wchar_t,wstring> & neighbours);
STRINGS CombineThem(const wstring& in,size_t n );
STRINGS PermutateF(wstring in);
STRINGS PowerSet(wstring in);
vector<size_t> GetPossiblePositions(size_t npos, int nDays);
#endif /* defined(__PlayArea__Play__) */
